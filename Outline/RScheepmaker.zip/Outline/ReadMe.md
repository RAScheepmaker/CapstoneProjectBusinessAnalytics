# ECO 6935 - Capstone Project Outline

Author: Remco A. Scheepmaker, Ph.D.
Date: May-Jun 2024

In order to run all the codes and 
compile the outline paper, simply execute 
the Compile.sh script by typing 
 ./Compile.sh 
from the Outline folder. 

The final outline paper will appear 
in the Outline folder as:

"RScheepmakerOutline.pdf"
